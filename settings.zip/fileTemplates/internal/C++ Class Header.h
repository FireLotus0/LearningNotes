#pragma once

#[[#include]]# <qobject.h>

${NAMESPACES_OPEN}
class ${NAME} : public QObject {
public:
    explicit ${NAME}(QObject* parent = nullptr);
};
${NAMESPACES_CLOSE}
