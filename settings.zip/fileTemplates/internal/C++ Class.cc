#[[#include]]# "${HEADER_FILENAME}"
${NAMESPACES_OPEN_CPP}
${NAME}::${NAME}(QObject* parent)
    : QObject(parent) 
{
}
${NAMESPACES_CLOSE_CPP}