# Qt Gui Application



## 说明

该项目为Gui应用程序模板项目，导入项目后需要进行以下初始化工作：

1. 运行git初始化子仓库

```bash
git submodule init
git submodule update
```

2. 填写bugreport应用key

arm/windows工程main函数需要配置应用程序key，忽略将导致bugreport无法上传崩溃信息，填写key如下代码所示：

```cpp
#ifdef QT_NO_DEBUG
    CrashListener crashListener("eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJBdXRoZW50aWNhdGlvbiIsImlzcyI6Ind3dy5lYW"
                                "50dGVjaC5jb20iLCJuYW1lIjoiYnVncmVwb3J0LXRlc3QifQ.V4HgOtImEXVWYdS_Y6TStap-xBdeFwIciR86X29kYYU");
    crashListener.setLogSaveCallback([] (const QString& logFilePath) {
        logcollector::QLogCollector::save(logFilePath);
    });
#endif
```

3. 发布程序需要修改应用配置信息

修改app.rc.in，配置应用程序描述：

```
BEGIN
    VALUE "CompanyName", "芯蚁科技有限公司"
    VALUE "FileDescription", "！！配置文件描述！！"
    VALUE "FileVersion", "@PROJECT_VERSION@"
    VALUE "InternalName", ""
    VALUE "LegalCopyright", "Copyright (C) 2022"
    VALUE "ProductName", "！！配置产品描述！！"
    VALUE "ProductVersion", "@PROJECT_VERSION@"
END
```

修改install.nsi.in，配置打包脚本：

```
;第一部分添加文件
Section "MainSection" SEC01
  SetOutPath "$INSTDIR"
  SetOverwrite ifnewer
	File /r *.dll
	File "${SYSTEM_PATH}\msvcp140.dll"
	File "${SYSTEM_PATH}\ucrtbase.dll"
	File "${SYSTEM_PATH}\vcruntime140.dll"
	File "${APP_NAME}.exe"
	File "bugreport.exe"

;第二部分卸载文件
Section Uninstall
  !insertmacro MUI_STARTMENU_GETFOLDER "Application" $ICONS_GROUP
  Delete "$INSTDIR\uninst.exe"
  Delete "$INSTDIR\*.dll"
  Delete "$INSTDIR\*.exe"
  Delete "$INSTDIR\platforms\*.*"
```
