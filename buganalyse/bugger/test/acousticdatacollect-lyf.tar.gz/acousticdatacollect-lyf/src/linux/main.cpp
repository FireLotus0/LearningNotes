#include "utils/transfermanager.h"
#include <QFile>
#include <qcoreapplication.h>

#include "utils/configadc.h"
#include "crashlistener.h"
#include <qlogcollector.h>

int main(int argc, char* argv[])
{

    /**
 * 初始化bugreport，注意填写key
 */
#ifdef QT_NO_DEBUG
CrashListener crashListener(ACCESS_KEY);
crashListener.setLogSaveCallback([] (const QString& logFilePath) {
    QFile logFile(logFilePath);
    if (logFile.open(QIODevice::WriteOnly | QIODevice::Truncate)) {
        logcollector::QLogCollector::save(&logFile);
        logFile.close();
    }
});
#endif

    auto rev = ad4630_reg_read(0xBFFF00);
    ad4630_reg_write(0x000A89);
    rev = ad4630_reg_read(0x800A00);

    // chip test
    rev = ad4630_reg_read(0x800B00);
//    xil_printf("%x\r\n",rev);
    rev = ad4630_reg_read(0x800C00);
//    xil_printf("%x\r\n",rev);

    ad4630_reg_write(0x002080);   // four lane + test mode : 0x84;  four lane + normal mode = 0x80
    ad4630_reg_write(0x001401);

    int sample = 2000000;   // 2kHz
    Xil_Out32(XPAR_BRAM_0_BASEADDR + 0x14, 200000000 / sample - 1);
    // mode
    Xil_Out32(XPAR_BRAM_0_BASEADDR, 0x00);

    QCoreApplication a(argc, argv);

    TransferManager::instance().startServer();

    return a.exec();
}