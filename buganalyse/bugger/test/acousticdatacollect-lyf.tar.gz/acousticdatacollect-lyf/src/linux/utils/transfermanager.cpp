#include "transfermanager.h"
#include "configadc.h"
#include <qdatetime.h>

//#define DEBUG_MODE

TransferManager &TransferManager::instance() {
    static TransferManager instance;
    return instance;
}

TransferManager::TransferManager(QObject *parent)
    : QObject(parent) {
    CODEC.registerType<BytesCodec<HostData>>(this, &TransferManager::onRecvHostData);
    CODES.registerType<FrameData, BytesCodec>();
    connectSignals();
    fpgaData1Reader = new FpgaData1Reader(this);
    sampleTimer.setInterval(BUFF_READ_FREQ);
    sampleTimer.callOnTimeout([&] {
        uploadData();
    });
    hostData.startSwitch = 0;

    uploadDataThr = ThreadManage::create<UploadDataThr>(&dataCache, &mt, &startFlag, &clientSocket);
    uploadDataThr->start();
}

TransferManager::~TransferManager() {
    stopServer();
}

void TransferManager::connectSignals() {
    connect(&server, &QTcpServer::newConnection, this, &TransferManager::onNewConnectionAccept);
    connect(&server, &QTcpServer::acceptError, this, [&](QAbstractSocket::SocketError error) {
        qDebug() << "accept error: " << server.errorString() << " " << error;
    });
}

void TransferManager::onNewConnectionAccept() {
    QMutexLocker locker(&mt);
    if (clientSocket != nullptr) {
        return;
    }
    clientSocket = server.nextPendingConnection();
    if (!clientSocket) {
        qDebug() << "New client socket is null!";
        return;
    }
    clientSocket->setReadBufferSize(1000 * 32768);
    connect(clientSocket, &QTcpSocket::readyRead, this, [&]() {
        QMutexLocker locker(&mt);
        auto data = clientSocket->readAll();
        CODEC.appendBuffer(data);
    });
    connect(clientSocket, &QTcpSocket::disconnected, clientSocket, [&](){
        onDisconnect();
    });
    connect(clientSocket, &QTcpSocket::errorOccurred, clientSocket, [&](QAbstractSocket::SocketError error) {
        onDisconnect();
    });
    qDebug() << "New client connected!";
}

void TransferManager::onRecvHostData(const HostData &data) {
    // 上位机确保其他参数正确
    if (data.isControlSwitch == 1) {// 控制启停
        if (hostData.startSwitch != data.startSwitch) {
            if (data.startSwitch == 1) {
                sampleTimer.start();
                startFlag.store(true, std::memory_order_release);
                qDebug() << "start sample!";
                unsigned int start = 0x03;
                Xil_Out32(XPAR_BRAM_0_BASEADDR, 0x03);
                //                fpgaData1Reader->writeToSharedMemory(XPAR_BRAM_0_BASEADDR, &start, 4); // 开始采样
            } else {
                sampleTimer.stop();
                startFlag.store(false, std::memory_order_release);
                qDebug() << "stop sample!";
                unsigned int stop = 0x00;
                //                fpgaData1Reader->writeToSharedMemory(XPAR_BRAM_0_BASEADDR, &stop, 4); // 开始采样
                Xil_Out32(XPAR_BRAM_0_BASEADDR, 0x00);
            }
        }
    } else {
        uint32_t way = data.way;
        uint32_t points = data.points;
        //        fpgaData1Reader->writeToSharedMemory(SAMPLE_WAY_ADDR, &way, 4); // 写入采集方式
        Xil_Out32(SAMPLE_WAY_ADDR, way);
        //        fpgaData1Reader->writeToSharedMemory(SAMPLE_POINT_COUNT_ADDR, &points, 4); // 写入采样点数
        Xil_Out32(SAMPLE_POINT_COUNT_ADDR, points);
        unsigned long rate = data.rate;
        switch (rate) {
            case 0:
                rate = 200000000 / 100000 - 1;
                break;// 100k
            case 1:
                rate = 200000000 / 250000 - 1;
                break;// 250k
            case 2:
                rate = 200000000 / 500000 - 1;
                break;// 500k
            case 3:
                rate = 200000000 / 1000000 - 1;
                break;// 1M
            case 4:
                rate = 200000000 / 2000000 - 1;
                break;// 2M
            default:
                qWarning() << "Wrong Sample Rate!";
                Q_ASSERT(false);
        }
        Xil_Out32(XPAR_BRAM_0_BASEADDR + 0x14, rate);
    }
    hostData = data;
    qDebug() << "recv host data: " << data;
}

void TransferManager::startServer() {
    // 启动服务器并监听端口
    if (!server.listen(QHostAddress::Any, 12345)) {
        qDebug() << "Server could not start!";
    } else {
        qDebug() << "Server started!";
    }
}

void TransferManager::stopServer() {
    uploadDataThr->quit();
    uploadDataThr->wait();
    if (clientSocket != nullptr) {
        if(clientSocket->isOpen()) {
            clientSocket->close();
        }
        clientSocket->deleteLater();
        clientSocket = nullptr;
    }
    if (server.isListening()) {
        server.close();
    }
    if (sampleTimer.isActive()) {
        sampleTimer.stop();
    }
    if (fpgaData1Reader) {
        delete fpgaData1Reader;
    }
    qDebug() << "Server Stopped!";
}

void TransferManager::uploadData() {
#ifdef DEBUG_MODE
    FrameData data;
    qDebug() << "upload one frame of data!" + QString::number(sizeof(data));
    if (isConnectionValid()) {
        clientSocket->write(CODES.encode<FrameData>(data));
    }
#else
    if (isFirstSample) {
        fpgaData1Reader->collectionBegin();
        isFirstSample = false;
    }
    fpgaData1Reader->dataPositionUpdate();
    auto data = fpgaData1Reader->packageData();
    for (const auto &frame: data) {
        if (isConnectionValid()) {
            dataCache.append(frame);
        }
    }
    qDebug() << "Write Package Finish!";
#endif
}
void TransferManager::onDisconnect() {
    QMutexLocker locker(&mt);
    if(!clientSocket) {
        clientSocket->deleteLater();
        clientSocket = nullptr;
    }
}
