#pragma once

#include "threadmanage.h"
#include "codecengine/customcodeengine.h"
#include "codecengine/bean/fpgadatareader.h"
#include "arrayobjectcache.h"
#include "uploaddatathr.h"

#include <qtcpsocket.h>
#include <qpointer.h>
#include <qtimer.h>
#include <qtcpserver.h>
#include <qfile.h>


#define PHYSICAL_BASE_ADDR 0x1000
#define PAGE_SIZE 4096
#define PACKAGE_SIZE 1024
#define PACKAGE_COUNT 1000

class TransferManager : public QObject
{
    Q_OBJECT
public:
    static TransferManager& instance();

    void startServer();

    void stopServer();

private:
    explicit TransferManager(QObject *parent = nullptr);

    ~TransferManager();

    void connectSignals();

    void onRecvHostData(const HostData& data);

    void uploadData();

    bool isConnectionValid() const {
        return clientSocket != nullptr && clientSocket->error() == QAbstractSocket::SocketError::UnknownSocketError;
    }

private slots:
    void onNewConnectionAccept();

    void onDisconnect();
private:
    HostData hostData;
    QTcpServer server;
    QTcpSocket* clientSocket{nullptr};
    QTimer sampleTimer;
    FpgaData1Reader* fpgaData1Reader;
    bool isFirstSample = true;
    UploadDataThr* uploadDataThr;
    QMutex mt;
    ArrayObjectCache<FrameData, 1000> dataCache;
    std::atomic_bool startFlag{false};
};
